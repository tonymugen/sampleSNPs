This file contains instructions to run the trials that compare Method D and Method S execution times. 

# Compilation

The two programs included here can be compiled in this directory by running

	g++ sampleTimeTPED.cpp ../random.cpp -o sampleTimeTPED -O3 -march=native -std=c++11
	g++ sampleTimeBED.cpp ../random.cpp -o sampleTimeBED -O3 -march=native -std=c++11
	
# Running the analyses

Each program takes the number or samples and the total number of records as space-delimited command line input (see the timingAnalyses.Rnw file for examples) and outputs the time taken by the Method D and Method S in that order on the standard out. The maximum number of records is 500 000 in the .bed and 100 000 in the .tped file. The timingAnalyses.Rnw R script wraps these analyses and generates plots. These should be similar to the ones published in the accompanying paper. The script depends on _ggplot2_, _gridExtra_, and _showtext_ packages. I also use the Myriad sans-serif font in my graphs, which is freely available. 

The R script can be run using _Sweave()_ or _Stangle()_.

