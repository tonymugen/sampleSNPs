/*
 * Copyright (c) 2017 Anthony J. Greenberg
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */
//
//  TPED file processing time
//
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cmath>
#include <ctime>
#include <cstdint>
#include <limits>

#include "../random.hpp"

using std::cout;
using std::endl;
using std::flush;
using std::string;
using std::vector;
using std::ofstream;
using std::ifstream;
using std::ios;
using std::numeric_limits;
using std::streamsize;

using namespace sampFiles;

int main(int argc, char *argv[]){
	
	// BED file processing
	string bedFile("sample_2L.tped");
	string outFile("testSample.tped");
	const uint64_t n = atoi(argv[1]); // # of remaining samples
	const uint64_t N = atoi(argv[2]); // # of remaining loci
	uint64_t S;                       // jump size
	RanDraw rng;                      // DRNG
	string tpedLine;
	// Vitter first
	uint64_t nTmp = n;
	uint64_t Ntmp = N;
	ifstream inBed(bedFile);
	ofstream outBed(outFile);
	// TPED file processing
	
	clock_t vTime = clock();
	while (nTmp) {
		S     = rng.vitter(nTmp, Ntmp);
		Ntmp -= S + 1;
		while (S) { // skipping S lines in the tped file
			//getline(inBed, tpedLine);
			inBed.ignore(numeric_limits<streamsize>::max(), '\n');
			S--;
		}
		getline(inBed, tpedLine);
		outBed << tpedLine << endl;
		nTmp--;
	}
	vTime = clock() - vTime;
	outBed.close();
	inBed.close();
	
	// Methods S
	// re-set everything
	nTmp = n;
	Ntmp = N;
	inBed.open(bedFile);
	outBed.open(outFile, ios::trunc);
	
	clock_t sTime = clock();
	while (nTmp) {
		if (static_cast<uint64_t>(Ntmp*rng.runif()) > nTmp) {
			//getline(inBed, tpedLine);
			inBed.ignore(numeric_limits<streamsize>::max(), '\n');
			Ntmp--;
		} else {
			getline(inBed, tpedLine);
			outBed << tpedLine << endl;
			nTmp--;
			Ntmp--;
		}
	}
	sTime = clock() - sTime;
	cout << 1000.0*static_cast<double>(vTime)/CLOCKS_PER_SEC << " " << 1000.0*static_cast<double>(sTime)/CLOCKS_PER_SEC << endl;
	
	outBed.close();
	inBed.close();

}



