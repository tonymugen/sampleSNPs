/*
 * Copyright (c) 2017 Anthony J. Greenberg
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */
//
//  BED file processing time
//
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cmath>
#include <ctime>
#include <cstdint>

#include "../random.hpp"

using std::cout;
using std::endl;
using std::flush;
using std::string;
using std::vector;
using std::ofstream;
using std::ifstream;
using std::ios;

using namespace sampFiles;

int main(int argc, char *argv[]){
	
	string bedFile("sample_ALL.bed");
	string outFile("testSample.bed");
	const uint64_t Nbed = 71;         // # of compact entry
	const uint64_t n = atoi(argv[1]); // # of remaining samples
	const uint64_t N = atoi(argv[2]); // # of remaining loci
	uint64_t cumS    = 0;             // cumulative jump size
	uint64_t S;                       // jump size
	char *bedLine;                    // line of the bed file
	RanDraw rng;                      // DRNG
	char magic[3] = {static_cast<char>(0x6C), static_cast<char>(0x1B), static_cast<char>(0x01)}; // magic bytes
	
	// Vitter first
	uint64_t nTmp = n;
	uint64_t Ntmp = N;
	ifstream inBed(bedFile, ios::binary);
	ofstream outBed(outFile, ios::binary);
	outBed.write(magic, 3);
	bedLine = new char[Nbed];
	clock_t vTime = clock();
	while (nTmp) {
		S     = rng.vitter(nTmp, Ntmp);
		cumS += S;
		Ntmp -= S + 1;
		inBed.seekg(cumS*Nbed + 3);
		inBed.read(bedLine, Nbed);
		cumS++;                        // step up cumS because we are jumping with seekg()
		outBed.write(bedLine, Nbed);
		nTmp--;
	}
	vTime = clock() - vTime;
	
	outBed.close();
	inBed.close();
	
	// Method S
	// first re-set everything
	nTmp = n;
	Ntmp = N;
	cumS = 0;
	inBed.open(bedFile, ios::binary);
	outBed.open(outFile, ios::binary | ios::trunc);
	outBed.write(magic, 3);
	clock_t sTime = clock();
	while (nTmp) {
		if (static_cast<uint64_t>(Ntmp*rng.runif()) > nTmp) {
			cumS++;
			Ntmp--;
		} else {
			inBed.seekg(cumS*Nbed + 3);
			inBed.read(bedLine, Nbed);
			outBed.write(bedLine, Nbed);
			cumS++;
			nTmp--;
			Ntmp--;
		}
	}
	sTime = clock() - sTime;
	cout << 1000.0*static_cast<double>(vTime)/CLOCKS_PER_SEC << " " << 1000.0*static_cast<double>(sTime)/CLOCKS_PER_SEC << endl;
	
	inBed.close();
	outBed.close();
	delete [] bedLine;
	
}



